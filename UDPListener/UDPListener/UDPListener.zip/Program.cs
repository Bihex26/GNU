﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace UDPListener
{
    class Program
    {
        private const int ListenPort = 5000;

        public static void Main()
        {
            bool done = false;
            UdpClient listener = new UdpClient(ListenPort);
            //IPAddress address = IPAddress.Parse("192.168.15.26");
            IPEndPoint groupEp = new IPEndPoint(IPAddress.Any, ListenPort);
            //IPEndPoint groupEp = new IPEndPoint(address, ListenPort);
            try
            {
                while (!done)
                {
                    Console.WriteLine("Waiting for broadcast");
                    var receiveByteArray = listener.Receive(ref groupEp);
                    Console.WriteLine("Received a broadcast from {0}", groupEp);

                    float[] floats = new float[receiveByteArray.Length / 4];

                    for (int i = 0; i < receiveByteArray.Length / 4; i++)
                        floats[i] = BitConverter.ToSingle(receiveByteArray, i * 4);

                    foreach (float f in floats)
                    {
                        Console.WriteLine( floats.Length + "--" + f + " || ");
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            listener.Close();
        }
    }
}

